# Looksee — image analysis project

A React + Vite frontend and Python + FastAPI backend for general image descriptions and visible-component identification. Uploaded JPG, PNG and WebP images (up to 10 MB) are analysed by a hosted vision-language model via OpenRouter. This repository contains the application source, deployment configuration, project requirements and an optional Google Colab notebook.

## Open in VS Code

1. Extract `Looksee_VS_Code_Project.zip`.
2. Open the extracted `Looksee_VS_Code_Project` folder in VS Code (`File → Open Folder`).
3. Install Python 3 and Node.js (which includes npm), if they are not already installed.
4. In VS Code, open two terminals using **Terminal → New Terminal**. Start the backend in one and the frontend in the other using the commands below.

## Configure your private model key

The ZIP deliberately contains **no API keys**. You need your own OpenRouter account/key for live image analysis. In the backend directory, copy `.env.example` to `.env` and replace the example value with your own key. Do not send, commit or publish your `.env` file. Never put the key in frontend configuration. The local frontend already defaults to `http://localhost:8000`; the `frontend/.env.example` file is only a reference.

## Run on Windows (PowerShell)

**Terminal 1 — backend:**

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env   # only the first time
# Edit backend/.env and replace the sample OPENROUTER_API_KEY before analysing images.
python -m uvicorn app.main:app --reload --port 8000
```

**Terminal 2 — frontend:**

```powershell
cd frontend
npm install
npm run dev
```

Open the local URL Vite prints (normally `http://localhost:5173`). Alternatively, from Windows you can run `start-image-classifier.cmd`; it creates the backend environment, installs dependencies, starts both servers, and opens the site. The two terminal windows it opens must remain running.

## Run on macOS or Linux

In the first terminal, from the project root:

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp .env.example .env   # first time only; edit .env to add your private key
python -m uvicorn app.main:app --reload --port 8000
```

Open a second terminal in the project root:

```bash
cd frontend
npm install
npm run dev
```

Visit `http://localhost:5173`.

## Troubleshooting

- **`OPENROUTER_API_KEY` error:** add your own valid key to `backend/.env` and restart the backend. Do not share the populated file.
- **Frontend cannot reach the API:** make sure both terminals are running and the backend is at `http://localhost:8000`; check browser network/CORS errors.
- **Model unavailable / rate limit:** the backend reports provider errors. Model availability and provider quotas may change; use a model available to your own OpenRouter account. API calls may consume your provider quota.
- **First startup:** installing Python and npm dependencies requires an internet connection.

## Project layout

- `frontend/` — React/Vite web application
- `backend/` — FastAPI image-validation and model API
- `backend/.env.example` — safe configuration template (not a real credential)
- `PRD.md` — project requirements
- `DEPLOYMENT.md`, `render.yaml` — hosting configuration and deployment notes
- `looksee_deep_learning_colab.ipynb` — optional Colab workflow; requests the key privately at runtime

## Safety and privacy

Looksee describes visible content; it does not confirm hidden components, diagnose faults, guarantee part compatibility or replace an expert. The backend sends an image to OpenRouter for analysis when the user submits it. Check provider terms and avoid uploading private or sensitive photos without permission.
